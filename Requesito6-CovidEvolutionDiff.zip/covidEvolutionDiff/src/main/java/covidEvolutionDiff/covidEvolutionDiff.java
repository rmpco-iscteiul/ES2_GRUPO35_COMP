package covidEvolutionDiff;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.LogCommand;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.diff.DiffFormatter;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.ObjectLoader;
import org.eclipse.jgit.lib.ObjectReader;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.treewalk.CanonicalTreeParser;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.eclipse.jgit.treewalk.filter.PathFilter;

/**
 * 
 * @author Pedro Bernardo 73158
 *
 */
public class covidEvolutionDiff {
	private static final String REMOTE_URL = "http://github.com/vbasto-iscte/ESII1920";
	private ArrayList<String> listaDiferencasMenos = new ArrayList<String>();
	private ArrayList<String> listaDiferencasMais = new ArrayList<String>();
	private Git git;
	private RevCommit ultimoCommit;
	private RevCommit penultimoCommit;

	/**
	 * 
	 * @return parte da lista de diferencas entre as duas versoes do ficheiro
	 */
	public ArrayList<String> getListaMenos() {
		return listaDiferencasMenos;
	}

	/**
	 * 
	 * @return parte da lista de diferencas entre as duas versoes do ficheiro do
	 *         ficheiro
	 */
	public ArrayList<String> getListaMais() {
		return listaDiferencasMais;
	}

	/**
	 * Inicia a ligacao ao git com o url "http://github.com/vbasto-iscte/ESII1920"
	 * 
	 * @throws IOException
	 * @throws GitAPIException
	 */
	public void getGit() throws IOException, GitAPIException {
		File localPath = File.createTempFile("TestGitRepository", "");
		if (!localPath.delete()) {
			throw new IOException("Could not delete temporary file " + localPath);
		}

		System.out.println("Cloning from " + REMOTE_URL + " to " + localPath);
		git = Git.cloneRepository().setURI(REMOTE_URL).setDirectory(localPath).setProgressMonitor(null).call();
		System.out.println("Having repository: " + git.getRepository().getDirectory());
		getUltimosFicheiros();
	}

	/**
	 * Obtem os ultimos dois commits/alteracoes com tags associadas
	 * 
	 * @throws IOException
	 * @throws GitAPIException
	 */
	public void getUltimosFicheiros() throws IOException, GitAPIException {
		ArrayList<RevCommit> listaResultado = new ArrayList<RevCommit>();
		List<Ref> call = git.tagList().call();
		for (Ref ref : call) {
			LogCommand log = git.log();

			Ref peeledRef = git.getRepository().getRefDatabase().peel(ref);
			if (peeledRef.getPeeledObjectId() != null) {
				log.add(peeledRef.getPeeledObjectId());
			} else {
				log.add(ref.getObjectId());
			}

			Iterable<RevCommit> logs = log.call();
			for (RevCommit rev : logs) {
				if (rev.getId().getName().equals(ref.getObjectId().getName())) {
					listaResultado.add(rev);
					System.out.println(ref.getObjectId().getName());
				}
			}
		}

		int ultimo = listaResultado.get(0).getCommitTime();
		ultimoCommit = listaResultado.get(0);
		int penultimo = 0;
		penultimoCommit = listaResultado.get(0);
		for (int i = 1; i < listaResultado.size(); i++) {
			if (listaResultado.get(i).getCommitTime() > ultimo) {
				penultimo = ultimo;
				penultimoCommit = ultimoCommit;
				ultimo = listaResultado.get(i).getCommitTime();
				ultimoCommit = listaResultado.get(i);
			} else {
				if (listaResultado.get(i).getCommitTime() > penultimo) {
					penultimo = listaResultado.get(i).getCommitTime();
					penultimoCommit = listaResultado.get(i);
				}
			}
		}
		System.out.println(" ultimo " + ultimoCommit.getName());
		System.out.println(" penultimo " + penultimoCommit.getName());
		getFicheiros();
	}

	/**
	 * Obtem os ficheiros relativos ao penultimo commit e ao ultimo commit
	 * 
	 * @throws IOException
	 * @throws GitAPIException
	 */
	public void getFicheiros() throws IOException, GitAPIException {
		try {
			TreeWalk treeWalk = new TreeWalk(git.getRepository());
			treeWalk.addTree(ultimoCommit.getTree());
			treeWalk.setRecursive(true);
			treeWalk.setFilter(PathFilter.create("covid19spreading.rdf"));
			if (!treeWalk.next()) {
				treeWalk.close();
				throw new IllegalStateException("Did not find expected file 'covid19spreading.rdf'");
			}

			ObjectId objectId = treeWalk.getObjectId(0);
			ObjectLoader loader = git.getRepository().open(objectId);
			byte[] bytes = loader.getBytes();
			FileOutputStream fos = new FileOutputStream("covid19spreadingUltimo.rdf");
			fos.write(bytes);
			fos.close();
			treeWalk.close();
		} catch (IOException e) {
			e.printStackTrace();

		}
		try {
			TreeWalk treeWalk1 = new TreeWalk(git.getRepository());
			treeWalk1.addTree(penultimoCommit.getTree());
			treeWalk1.setRecursive(true);
			treeWalk1.setFilter(PathFilter.create("covid19spreading.rdf"));
			if (!treeWalk1.next()) {
				treeWalk1.close();
				throw new IllegalStateException("Did not find expected file 'covid19spreading.rdf'");
			}

			ObjectId objectId = treeWalk1.getObjectId(0);
			ObjectLoader loader = git.getRepository().open(objectId);
			byte[] bytes = loader.getBytes();
			FileOutputStream fos1 = new FileOutputStream("covid19spreadingPenultimo.rdf");
			fos1.write(bytes);
			fos1.close();
			treeWalk1.close();

		} catch (IOException e) {
			e.printStackTrace();

		}
		getDiferencas();
	}

	/**
	 * Obtem as listas de diferen�as entre o penultimo commit e ultimo commit
	 * (guarda nas listas listaDiferencasMenos/listaDiferencaMais)
	 * 
	 * @throws IOException
	 * @throws GitAPIException
	 */
	public void getDiferencas() throws IOException, GitAPIException {

		ObjectReader reader = git.getRepository().newObjectReader();
		CanonicalTreeParser oldTreeIter = new CanonicalTreeParser();
		oldTreeIter.reset(reader, penultimoCommit.getTree());
		CanonicalTreeParser newTreeIter = new CanonicalTreeParser();
		newTreeIter.reset(reader, ultimoCommit.getTree());

		OutputStream bw = new ByteArrayOutputStream();

		DiffFormatter diffFormatter = new DiffFormatter(bw);
		diffFormatter.setRepository(git.getRepository());
		List<DiffEntry> entries = diffFormatter.scan(newTreeIter, oldTreeIter);
		diffFormatter.format(entries);
		diffFormatter.close();
		FileOutputStream fos1 = new FileOutputStream("covid19Diferencas.rdf");
		fos1.write(bw.toString().getBytes());
		fos1.close();
		String[] termos = bw.toString().split("\n");
		for (int i = 5; i < termos.length; i++) {
			if (termos[i].startsWith("-")) {
				listaDiferencasMenos.add(termos[i]);
			}
			if (termos[i].startsWith("+")) {
				listaDiferencasMais.add(termos[i]);
			}
		}

	}

}
