package covidEvolutionDiff;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.eclipse.jgit.api.errors.GitAPIException;

/**
 * 
 * @author Pedro Bernardo 73158
 *
 */
public class html {
	/**
	 * Formato html que ser� visto na pagina web quando selecionado "Covid Evolution"
	 * 
	 * @throws IOException
	 * @throws GitAPIException
	 */
	public static void criarHtmlDiff() throws IOException, GitAPIException {
		covidEvolutionDiff teste = new covidEvolutionDiff();
		teste.getGit();
		File destFile = new File("tableDiferencas.html");
		destFile.createNewFile();
		BufferedWriter bw = new BufferedWriter(new FileWriter(destFile));

		String begin = "<!DOCTYPE html>\r\n" + "<html>\r\n" + "<head>\r\n" + "<style>\r\n" + "table {\r\n"
				+ "  font-family: arial, sans-serif;\r\n" + "  border-collapse: collapse;\r\n" + "}\r\n" + "\r\n"
				+ "td, th {\r\n" + "  border: 3px solid #dddddd;\r\n" + "}\r\n" + "\r\n" + "tr:nth-child(even) {\r\n"
				+ "  background-color: #dddddd;\r\n" + "}\r\n" + "</style>\r\n" + "</head>\r\n" + "<body>\r\n" + "\r\n"
				+ "<h2>COVID EVOLUTION</h2>\r\n" + "\r\n" + "<table>\r\n" + "  <tr>\r\n"
				+ "    <th>Penultimo Commit</th>\r\n" + "    <th>Ultimo Commit</th>\r\n" + "	</tr>\r\n";

		String fin = "</table>\r\n" + "\r\n" + "</body>\r\n" + "</html>\r\n";
		String conteudoPenultimoCommit = new String(Files.readAllBytes(Paths.get("covid19spreadingPenultimo.rdf")));
		String conteudoUltimoCommit = new String(Files.readAllBytes(Paths.get("covid19spreadingUltimo.rdf")));
		System.out.println(teste.getListaMais());
		String linha1 = "";
		linha1 = linha1 + "<tr>\r\n" + "    <th> " + conteudoPenultimoCommit.replace("<", "(").replace(">", ")").replace("http://www.semanticweb.org/vbasto/ontologies/2020/4/untitled-ontology-3", "")
				+ "</th>" + "<th>" + conteudoUltimoCommit.replace("<", "(").replace(">", ")").replace("http://www.semanticweb.org/vbasto/ontologies/2020/4/untitled-ontology-3", "") + "</th>\r\n";

		for (int i = 0; i < teste.getListaMenos().size(); i++) {
			linha1 = linha1 + "<tr>\r\n" + "<th>" + teste.getListaMais().get(i).replace("<", "(").replace(">", ")")
					+ "</th>\r\n" + "<th>" + teste.getListaMenos().get(i).replace("<", "(").replace(">", ")")
					+ "</th>\r\n" + "</tr>\r\n";
		}

		bw.write(begin + linha1 + fin);
		bw.close();
	}

	public static void main(String[] args) throws IOException, GitAPIException {
		new html().criarHtmlDiff();
	}
}