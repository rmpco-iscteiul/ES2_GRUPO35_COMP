package covidEvolutionDiff;

import static org.junit.Assert.*;

import org.junit.Test;

public class covidEvolutionDiffTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	

}
