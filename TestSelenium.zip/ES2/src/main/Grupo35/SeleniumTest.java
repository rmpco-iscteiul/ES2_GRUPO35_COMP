package Grupo35;

import java.awt.AWTException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * 
 * @author Rui Cavaco/82391 - LEI
 *
 */
public class SeleniumTest {

	WebDriver driver;
	public String[] webpages = { "Home", "Covid Scientific Discoveries", "Covid Spread", "Covid Queries", "Covid Evolution",
			"Covid Wiki", "FAQ", "Contact Us", "Join Us", "About Us", "Covid Scientific Discoveries Repository" };
	EmailSending es;

	/**
	 * Initiator of Browser and tests to the web site.
	 * 
	 * @throws InterruptedException
	 * @throws AWTException
	 */
	public void launchBrowser() throws InterruptedException, AWTException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Rui\\Desktop\\selenium-java-3.141.59\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
//		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.1.64/");
		Thread.sleep(2000);
		testWebSitePages();
//		testLogins();
//		testForms();
		closeDriver();
	}

	/**
	 * Close the driver.
	 */
	public void closeDriver() {
		driver.quit();
	}

	/**
	 * Test is if the forms are working properly.
	 */
	public void testForms() {
		// TODO Auto-generated method stub
	}

	/**
	 * Method to check if logins are up and running.
	 * 
	 * @throws AWTException
	 * @throws InterruptedException
	 */
	public void testLogins() throws AWTException, InterruptedException {
		driver.get("http://192.168.1.64/wp-admin");
		sendEmail("Logins");
	}

	/**
	 * Method to check if web pages are up.
	 * 
	 * @throws InterruptedException
	 * @throws AWTException
	 */
	public void testWebSitePages() throws InterruptedException, AWTException {
		String wprm;
		int i = 0;
		for (String wp : webpages) {
			wprm = wp;
			driver.findElement(By.xpath("//*[@id=\"site-header\"]/div[1]/div[2]/div/div[1]/button")).click();
			Thread.sleep(2000);
			driver.findElement(By.linkText(wp)).click();
			if (driver.getTitle().equals("Database Error") || driver.getTitle().equals("192.168.1.64")) {
				sendEmail("Paginas");
			}
			Thread.sleep(2000);
			driver.get("http://192.168.1.64/");
			webpages[i] = null;
			i++;
		}
	}

	/**
	 * 
	 * Method to initiate the writing of the email warning about the concurrent
	 * problem.
	 * 
	 * @param wp - String with the name of the problem.
	 * @throws AWTException
	 * @throws InterruptedException
	 */
	public void sendEmail(String wp) throws AWTException, InterruptedException {
		es = new EmailSending(wp);
		es.loginIntoMail();
		es.sendEmail();
	}

	public static void main(String[] args) throws InterruptedException, AWTException {
		SeleniumTest obj = new SeleniumTest();
		obj.launchBrowser();
	}

}
