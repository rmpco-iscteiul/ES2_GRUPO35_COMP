package Grupo35;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * 
 * @author Rui Cavaco/82391 - LEI
 *
 */
public class EmailSending {

	WebDriver driver;
	String AdminEmail = "rmpco@iscte-iul.pt";
	String FROM = "testeES2@hotmail.com"; 
	String PASSWORD = "TesteR123";
	String problema;

	/**
	 * Builder for email creation.
	 * @param wp - Name of the problem.
	 */
	public EmailSending(String wp) {
		this.problema = wp;
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Rui\\Desktop\\selenium-java-3.141.59\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	/**
	 * Login into mail.
	 * @throws InterruptedException
	 */
	public void loginIntoMail() throws InterruptedException {
		driver.get("https://outlook.live.com/owa/");
		driver.findElement(By.linkText("Sign in")).click();
		Thread.sleep(2000);
		// Insert email
		driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys(FROM);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"idSIButton9\"]")).click();
		Thread.sleep(2000);
		// Insert password and login
		driver.findElement(By.xpath("//input[@id='i0118']")).sendKeys(PASSWORD);
		driver.findElement(By.xpath("//*[@id=\"idSIButton9\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"idBtn_Back\"]")).click();
	}

	/**
	 * Production of the email warning about which functionality is not working properly.
	 * @throws InterruptedException
	 */
	public void sendEmail() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"id__3\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"//*[@id=\"app\"]/div/div[2]/div[1]/div/div[3]/div[2]/div/div[3]/div[1]/div/div/div/div[1]/div[1]/div[1]/div[1]/div[1]/div/div/div/div/div[1]/div/div/input"))
				.sendKeys(AdminEmail);
		switch (problema) {
		case "Paginas":
			driver.findElement(By.xpath("//*[@id=\"TextField997\"]")).sendKeys("Wordpress - Página com problema.");
			break;
		case "Logins":
			driver.findElement(By.xpath("//*[@id=\"TextField997\"]")).sendKeys("Wordpress - Logins com problema.");
			break;
		case "Forms":
			driver.findElement(By.xpath("//*[@id=\"TextField997\"]")).sendKeys("Wordpress - Forms com problema.");
			break;
		}
	}
}
