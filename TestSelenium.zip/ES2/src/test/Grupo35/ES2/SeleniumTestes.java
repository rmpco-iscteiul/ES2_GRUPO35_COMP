package Grupo35.ES2;

import static org.junit.Assert.assertEquals;

import java.awt.AWTException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import Grupo35.SeleniumTest;

@RunWith(JUnit4.class)
public class SeleniumTestes {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		SeleniumTest test;
	}

	@Test
	public void testPages() throws InterruptedException, AWTException {
		SeleniumTest test = new SeleniumTest();
		test.testWebSitePages();
		assertEquals(0, test.webpages.length);
	}

	@Test
	public void testBrowser() throws InterruptedException, AWTException {
		SeleniumTest test = new SeleniumTest();
		test.launchBrowser();
		assertEquals(11, test.webpages.length);
	}

	@Test
	public void testEmail() throws InterruptedException, AWTException {
		SeleniumTest test = new SeleniumTest();
		test.sendEmail("teste");
		String problema = "teste";
		assertEquals("teste", problema);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		SeleniumTest test = new SeleniumTest();
		test.closeDriver();
	}

}
