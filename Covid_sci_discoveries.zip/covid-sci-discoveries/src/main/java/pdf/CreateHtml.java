package pdf;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author Hugo Pereira
 *
 */
public class CreateHtml {
	List<String> htmlList = new ArrayList<String>();
	File htmlFile = new File("covid_sci_discoveries.html");
	String allHtml = "";

	public CreateHtml(List<ExtractPdf> buildList) {
		// TODO Auto-generated constructor stub
		for (ExtractPdf s : buildList) {
			String title = s.getArticleTitle();
			String journal = s.getJournalName();
			String year = s.getPublicationYear();
			String path = s.getFilePath();
			ArrayList<String> author = s.getAuthorList();
			htmlList.add("<tr><td><a href=" + path + ">" + title + "</a></td><td>" + journal + "</td><td>" + year
					+ "</td><td>" + author + "</td></tr>");
		}

		htmlBuilder();

	}

	/**
	 * this method builds html file
	 */
	private void htmlBuilder() {
		// TODO Auto-generated method stub
		try {
			htmlFile.createNewFile();
			BufferedWriter bw = new BufferedWriter(new FileWriter(htmlFile));
			String start = "<!DOCTYPE html>\r\n" + "<html>\r\n" + "<head>\r\n" + "<style>\r\n" + "table {\r\n"
					+ "  font-family: arial, sans-serif;\r\n" + "  border-collapse: collapse;\r\n" + "}\r\n" + "\r\n"
					+ "td, th {\r\n" + "  border: 1px solid #dddddd;\r\n" + "}\r\n" + "\r\n"
					+ "tr:nth-child(even) {\r\n" + "  background-color: #dddddd;\r\n" + "}\r\n" + "</style>\r\n"
					+ "</head>\r\n" + "<body>\r\n" + "\r\n" + "<h2>HTML Table</h2>\r\n" + "\r\n" + "<table>\r\n"
					+ "  <tr>\r\n" + "    <th><h2>Article title</h2></th>\r\n"
					+ "    <th><h2>Journal Name</h2></th>\r\n" + "    <th><h2>Publication Year</h2></th>\r\n"
					+ "    <th><h2>Authors</h2></th>\r\n" + "	</tr>\r\n";

			String end = "</table>\r\n" + "\r\n" + "</body>\r\n" + "</html>\r\n";
			joinHtmls();
			bw.write(start + allHtml + end);
			System.out.println(allHtml);
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * this method join all html from htmlList in one string
	 */
	private void joinHtmls() {
		for (String s : htmlList) {
			allHtml += s;
		}

	}

}
