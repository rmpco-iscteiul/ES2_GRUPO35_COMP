package pdf;
/**
 * @author Hugo Pereira
 *
 */
import java.io.File;
import java.util.ArrayList;

/**
 * 
 * @author Hugo Pereira
 *
 *This class extract the scientific articles metadata from each pdf document 
 */
public class MetadataFromAllPdf {
	private final static String fileDirectory = "pdf/";
	private ArrayList<ExtractPdf> metadataList= new ArrayList<ExtractPdf>();
	public MetadataFromAllPdf() {
		checkMetadataFromPdfs();
		new CreateHtml(metadataList);
	}
	/**
	 * Access the list of pdf documents available in the Covid Scientific Discoveries Repository.
	 *  These pdf documents correspond to scientific articles about Covid-19,
	 *   available in a filesystem folder called "pdf";
	 */
	public void checkMetadataFromPdfs() {
		
		File folder = new File(fileDirectory);
		File[] listOfFiles = folder.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
		  if (listOfFiles[i].isFile()) {
			  System.out.println(listOfFiles[i].getName());
			  	metadataList.add(new ExtractPdf(fileDirectory+listOfFiles[i].getName()));
		  } else if (listOfFiles[i].isDirectory()) {
		  }
		  
		}
	}
	public static void main(String[] args) {
		new MetadataFromAllPdf();
	}
}
