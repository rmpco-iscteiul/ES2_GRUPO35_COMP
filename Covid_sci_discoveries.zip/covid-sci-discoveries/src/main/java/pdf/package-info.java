/**
 * 
 */
/**
 * @author Hugo Pereira
 * 
 * Package responsible by extract metadata from pdf
 *
 */
package pdf;