package pdf;

/**
 * @author Hugo Pereira
 *
 */

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import pl.edu.icm.cermine.ContentExtractor;
import pl.edu.icm.cermine.exception.AnalysisException;
import pl.edu.icm.cermine.metadata.model.DateType;
import pl.edu.icm.cermine.metadata.model.DocumentMetadata;
import pl.edu.icm.cermine.tools.timeout.TimeoutException;

/**
 * 
 * @author Hugo Pereira
 *
 *This class extracts the metadata from a pdf file and save them in local variables
 */
public class ExtractPdf {
	
	private ContentExtractor extractor;
	private ArrayList<String> authorList = new ArrayList<String>() ;
	private String articleTitle ;
	private String journalName;
	private String publicationYear;
	private String filePath;

	/**
	 * Extract data from a pdf file
	 * @param filePath- name of the pdf file
	 */
	public ExtractPdf(String filePath) {
		this.filePath = filePath;
		extractPdf();
		extractMetadata();
		
	}
	public String getFilePath() {
		return filePath;
	}
	public ArrayList<String> getAuthorList() {
		return authorList;
	}
	public String getArticleTitle() {
		return articleTitle;
	}
	public String getJournalName() {
		return journalName;
	}
	public String getPublicationYear() {
		return publicationYear;
	}
	/**
	 * this method fills "extractor" field whit a ContentExtractor who will get the data 
	 */
	public void extractPdf() {
		try {
			 extractor = new ContentExtractor();
			InputStream inputStream = new FileInputStream( filePath);

			
			extractor.setPDF(inputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AnalysisException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * this method get the pretended data and saves them in local string variables
	 */
	public void extractMetadata() {
		try {
			DocumentMetadata metadata = extractor.getMetadata();
			for( int i=0; i< metadata.getAuthors().size(); i++) {
			authorList.add(metadata.getAuthors().get(i).getName());
			}
			articleTitle=metadata.getTitle();
			journalName = metadata.getJournal();
			publicationYear = metadata.getDate(DateType.PUBLISHED).getYear();
			System.out.println("Article Title: "+articleTitle+ " Journal Name: " + journalName + " publicationYear : "+publicationYear);
		} catch (TimeoutException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AnalysisException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
