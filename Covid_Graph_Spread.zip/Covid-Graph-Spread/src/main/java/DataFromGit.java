import java.io.File;
import java.io.IOException;
import java.util.List;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.LogCommand;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.NoHeadException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.revwalk.RevCommit;

/**
 * 
 * 
 * 
 * @author Pedro
 *
 */

/**
 * 
 * This Class will be used to retrieve all information from the repository
 * This program connects to Git
 * Accesses the covid19spreading.rdf file available in the repository
 * Retrieves all covid19spreading.rdf file versions that have tags associated
 * Builds a HTML table
 * 
 *
 */
public class DataFromGit {

	/** Represents the address repository.*/
	private final static String repositoryURL = "https://github.com/vbasto-iscte/ESII1920";
	
	/** Represents the Git version control system.*/
	private Git git;

	public DataFromGit() {
		cloneFileFromRepository();
	}

	/**
	 * 
	 * This method connects to Git
	 * Accesses the covid19spreading.rdf file available in the repository	
	 * Retrieves all covid19spreading.rdf file versions that have tags associated
	 * 
	 * 
	 */
	public void cloneFileFromRepository() {
		File localPath;
		try {
			localPath = File.createTempFile("TestGitRepository", "");
			if (!localPath.delete()) {
				throw new IOException("Could not delete temporary file " + localPath);
			}
			git = Git.cloneRepository().setURI(repositoryURL).setDirectory(localPath).setProgressMonitor(null).call();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InvalidRemoteException e) {
			e.printStackTrace();
		} catch (TransportException e) {
			e.printStackTrace();
		} catch (GitAPIException e) {
			e.printStackTrace();
		}

	}
	
	
	/**
	 * 
	 * This method is to get Tags from all the files
	 * 
	 */
	public List<Ref> getTags() {
		try {
			return git.tagList().call();
		} catch (GitAPIException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 
	 * This method is to get the Commits
	 * from a specific tag
	 *
	 * @param tag - a specific tag to get commits that have this tag
	 */
	public Iterable<RevCommit> getCommits(Ref tag) {
		LogCommand log = git.log();
		Ref peeledRef;
		try {
				peeledRef = git.getRepository().getRefDatabase().peel(tag);
				if (peeledRef.getPeeledObjectId() != null) {
					log.add(peeledRef.getPeeledObjectId());
				} else {
					log.add(tag.getObjectId());
				}
			System.out.println("Commit " + tag.getObjectId());
			return log.call();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NoHeadException e) {
			e.printStackTrace();
		} catch (GitAPIException e) {
			e.printStackTrace();
		}
		return null;

	}
	
}
