import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
/** 
* 
* @author Pedro 
*/

/**
 * 
 * This program connects to Git
 * Accesses the covid19spreading.rdf file available in the repository
 * Retrieves all covid19spreading.rdf file versions that have tags associated
 * Builds a HTML table
 * 
 * 
 *
 */
public class Html {
	
	private DataFromGitFile dataList;
	
	/**
	 * 
	 * 	Method to create HTML
	 * 	
	 * 
	 */
	public void createTable() {
		
		dataList = new DataFromGitFile();
		File destFile = new File("tableToHtml.html");
		
		try {
			destFile.createNewFile();
			BufferedWriter bw = new BufferedWriter(new FileWriter(destFile));
			String begin = "<!DOCTYPE html>\r\n" + "<html>\r\n" + "<head>\r\n" + "<style>\r\n" + "table {\r\n"
					+ "  font-family: arial, sans-serif;\r\n" + "  border-collapse: collapse;\r\n" + "}\r\n" + "\r\n"
					+ "td, th {\r\n" + "  border: 1px solid #dddddd;\r\n" + "}\r\n" + "\r\n" + "tr:nth-child(even) {\r\n"
					+ "\r\n" + "}\r\n" + "</style>\r\n" + "</head>\r\n" + "<body>\r\n" + "\r\n"
					+ "<h2>HTML Table</h2>\r\n" + "\r\n" + "<table>\r\n" + "  <tr>\r\n" + "    <th>File timestamp</th>\r\n"
					+ "    <th>File name</th>\r\n" + "    <th> File tag</th>\r\n" + "    <th>Tag Description</th>\r\n"
					+ "    <th>Spread Visualization Link</th>\r\n" + "	</tr>\r\n";

			String fin = "</table>\r\n" + "\r\n" + "</body>\r\n" + "</html>\r\n";
			String linha = "";
			for (int i = 0; i < dataList.getCompleteList().get(0).size(); i++) {
				System.out.println(dataList.getCompleteList().get(0).get(i));
				linha = linha + "  <tr>\r\n" + "    <th> " + dataList.getCompleteList().get(0).get(i) + "</th>\r\n"
						+ "    <th> " + dataList.getCompleteList().get(1).get(i) + "</th>\r\n" + "    <th> "
						+ dataList.getCompleteList().get(2).get(i) + "</th>\r\n" + "    <th> "
						+ dataList.getCompleteList().get(3).get(i) + "</th>\r\n" + "    <th> "
						+ "<a href=\"http://visualdataweb.de/webvowl/#iri=" + dataList.getCompleteList().get(4).get(i)
						+ "\" title=\"Check the link here!\">LINK</a> " + "</th>\r\n" + "    <th> "

						+ "</th>\r\n" + "	</tr>\r\n";
			}
			bw.write(begin + linha + fin);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		/**
		 * 
		 * 	This is the main method
		 * 	Execution for this java project
		 * 
		 */
		Html html = new Html();
		html.createTable();
	}

}
