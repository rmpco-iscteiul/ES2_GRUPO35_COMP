//cada tag esta assoçiado a un commit, ele vai associar um comit numa tage, cada tag é uma entrada das 5 listas. é uma linha no html.

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.eclipse.jgit.lib.PersonIdent;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.revwalk.RevCommit;

/**
 * 
 * 
 * @author Pedro
 *
 */
public class DataFromGitFile {
	
	private List<ArrayList<String>> completeList = new ArrayList<ArrayList<String>>();
	private ArrayList<String> listTimestamp = new ArrayList<String>();
	private ArrayList<String> listFileName = new ArrayList<String>();
	private ArrayList<String> listTag = new ArrayList<String>();
	private ArrayList<String> listTagDescription = new ArrayList<String>();
	private ArrayList<String> listSpreadVisualizationLink = new ArrayList<String>();
	private List<Ref> tagFromGit;
	private DataFromGit extractFileFromGit;

	
	public DataFromGitFile() {
		extractFileFromGit = new DataFromGit();
		this.tagFromGit = extractFileFromGit.getTags();
		ifCommitHasTags();
	}

	
	/**
	 * 
	 * Confirm if commit has tags
	 * If so add to a certain List (a temporary one)
	 * and then add to a final List (completeList)
	 * 
	 */
	public void ifCommitHasTags() {
		for (Ref tag : tagFromGit) {
			Iterable<RevCommit> commitList = extractFileFromGit.getCommits(tag);
			for (RevCommit commit : commitList) {
				if (commit.getId().getName().equals(tag.getObjectId().getName())) {
					addToTempLists(tag,commit);
				}
			}
		}
		addCompleteList();
	}


	/**
	 * 
	 * Called from the previous method (ifCommitHasTags)
	 * and add Time, FileName, TagDescription, Tag and the spreadVisualizationLink
	 * 
	 * @param tag - tag from a list of tags
	 * @param commit - Commit from a list of commits
	 * 
	 */
	public void addToTempLists(Ref tag, RevCommit commit) {
		PersonIdent authorIdent = commit.getAuthorIdent();
		Date authorDate = authorIdent.getWhen();
		listTimestamp.add(String.valueOf(authorDate));
		listFileName.add("covid19spreading.rdf");
		listTag.add(tag.getObjectId().getName());
		listTagDescription.add(commit.getFullMessage());
		listSpreadVisualizationLink.add("https://raw.githubusercontent.com/vbasto-iscte/ESII1920/"+ tag.getObjectId().getName() 
				+ "/covid19spreading.rdf");
		System.out.println(String.valueOf(authorDate) + tag.getObjectId().getName() + commit.getFullMessage());
	}


	
	/**
	 * 
	 * This method add to a List of ArrayLists (completeList),
	 * the lists that were added in the previous method
	 * 
	 */
	public void addCompleteList() {
		completeList.add(listTimestamp);
		completeList.add(listFileName);
		completeList.add(listTag);
		completeList.add(listTagDescription);
		completeList.add(listSpreadVisualizationLink);
	}

	/**
	 * 
	 * getter for the completeList
	 */
	public List<ArrayList<String>> getCompleteList() {
		return completeList;
	}

}
