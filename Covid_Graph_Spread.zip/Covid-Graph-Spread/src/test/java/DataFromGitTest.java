import static org.junit.Assert.*;

import java.util.List;

import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.revwalk.RevCommit;
import org.junit.Test;

public class DataFromGitTest {

	
	/**
	 * JUnit test from DataFromGit
	 * method getTags
	 */
	@Test
	public void testGetTags() {
		DataFromGit test = new DataFromGit();
		List<Ref> ref = test.getTags();
		assertNotNull(null, ref);
	}

	/**
	 * JUnit test from DataFromGit
	 * method getCommits
	 */
	@Test
	public void testGetCommits() {
		DataFromGit test = new DataFromGit();
		Ref tagTest = test.getTags().get(1);
		Iterable<RevCommit> rev = test.getCommits(tagTest);
		assertNotNull(null, rev);
	}
}
